//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int {
    
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    init(velocidadInicial : Velocidades ) {
        self = velocidadInicial
    }
}

class Auto{
    var velocidad : Velocidades
    init() {
        self.velocidad = Velocidades.Apagado
    }
    
    func CambioDeVelocidad() -> ( actual : Int, velocidadEnCadena: String){
        let velocidadActual : Velocidades = self.velocidad
        var mensaje = ""
        
        switch self.velocidad {
        case Velocidades.Apagado:
            self.velocidad = Velocidades.VelocidadBaja
            mensaje = "\(velocidadActual.rawValue), Apagado"
        case Velocidades.VelocidadBaja:
            self.velocidad = Velocidades.VelocidadMedia
            mensaje = "\(velocidadActual.rawValue), Velocidad baja"
        case Velocidades.VelocidadMedia:
            self.velocidad = Velocidades.VelocidadAlta
            mensaje = "\(velocidadActual.rawValue), Velocidad media"

        default:
            self.velocidad = Velocidades.VelocidadMedia
            mensaje = "\(velocidadActual.rawValue), Velocidad alta"
        }
        let resultado = (velocidadActual.rawValue, mensaje)
        return resultado
    }
}


var auto : Auto = Auto()

auto.velocidad

for var i in 0...19{
    let (actual, texto) = auto.CambioDeVelocidad()
    print(texto)
}